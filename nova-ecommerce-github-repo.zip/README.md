# NOVA E-commerce Website

A simple static e-commerce website demo built with HTML, CSS, and JavaScript.

## Run locally
Open `index.html` in your browser.

## Publish with GitHub Pages
1. Create a new repository on GitHub.
2. Upload `index.html` and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.

GitHub Pages will provide a public URL after deployment.

## Note
This is a front-end demo. Real payments, customer accounts, inventory, and order processing are not connected.
